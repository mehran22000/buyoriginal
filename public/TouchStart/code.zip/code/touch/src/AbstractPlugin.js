/**
 * @private
 * This is a compatibility class.
 */
Ext.define('Ext.AbstractPlugin', {});